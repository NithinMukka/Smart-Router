export interface Airport {
    id: string;
    name: string;
    x: number;
    y: number;
  }
  
  export const airports: Airport[] = [
    { id: 'A', name: 'A', x: 50, y: 50 },
    { id: 'B', name: 'B', x: 185, y: 100 },
    { id: 'C', name: 'C', x: 300, y: 25 },
    { id: 'D', name: 'D', x: 200, y: 200 },
    { id: 'E', name: 'E', x: 400, y: 75 },
    { id: 'F', name: 'F', x: 311, y: 225 },
    { id: 'G', name: 'G', x: 50, y: 165 },
    { id: 'H', name: 'H', x: 119, y: 237 },
    { id: 'I', name: 'I', x: 250, y: 126 },
    { id: 'J', name: 'J', x: 400, y: 150 }
  ];