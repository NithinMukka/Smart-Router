export interface Route {
    from: string;
    to: string;
    distance: number;
    weather: 'clear' | 'rain' | 'storm';
    altitude: 'low' | 'medium' | 'high';
    fuelCost: number;
  }
  
  export const initialRoutes: Route[] = [
    { from: 'A', to: 'B', distance: 350, weather: 'clear', altitude: 'low', fuelCost: 1000 },
    { from: 'B', to: 'C', distance: 500, weather: 'rain', altitude: 'low', fuelCost: 800 },
    { from: 'A', to: 'C', distance: 900, weather: 'clear', altitude: 'high', fuelCost: 400 },
    { from: 'A', to: 'G', distance: 250, weather: 'rain', altitude: 'low', fuelCost: 399 },
    { from: 'G', to: 'H', distance: 200, weather: 'clear', altitude: 'low', fuelCost: 120 },
    { from: 'C', to: 'E', distance: 299, weather: 'clear', altitude: 'low', fuelCost: 140 },
    { from: 'B', to: 'I', distance: 150, weather: 'storm', altitude: 'medium', fuelCost: 100 },
    { from: 'H', to: 'D', distance: 175, weather: 'rain', altitude: 'low', fuelCost: 187 },
    { from: 'D', to: 'F', distance: 225, weather: 'clear', altitude: 'medium', fuelCost: 217 },
    { from: 'H', to: 'F', distance: 396, weather: 'clear', altitude: 'low', fuelCost: 517 },
    { from: 'F', to: 'J', distance: 299, weather: 'storm', altitude: 'high', fuelCost: 600 },
    { from: 'G', to: 'I', distance: 1000, weather: 'clear', altitude: 'low', fuelCost: 800 },
    { from: 'I', to: 'J', distance: 311, weather: 'clear', altitude: 'medium', fuelCost: 670 },
    { from: 'E', to: 'I', distance: 313, weather: 'clear', altitude: 'low', fuelCost: 689 }
  ];