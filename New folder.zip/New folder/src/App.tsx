import React, { useState, useEffect } from 'react';
import { NetworkMap } from './components/networkmap';
import { WeatherIcon } from './components/weathericon';
import { airports } from './data/airports';
import { initialRoutes } from './data/routes';
import { conditionFactors } from './constants/conditions';
import type { Route } from './data/routes';

function SmartAirliftRouter() {
  const [routes, setRoutes] = useState<Route[]>(initialRoutes);
  const [source, setSource] = useState('');
  const [destination, setDestination] = useState('');
  const [routingPriority, setRoutingPriority] = useState('balanced');
  const [availableRoutes, setAvailableRoutes] = useState<Array<{ path: string[]; cost: number }>>([]);
  const [selectedRoute, setSelectedRoute] = useState<{ path: string[]; cost: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [planePosition, setPlanePosition] = useState(0);
  const [isSimulating, setIsSimulating] = useState(false);

  useEffect(() => {
    if (selectedRoute) {
      setPlanePosition(0);
      setIsSimulating(true);
    } else {
      setIsSimulating(false);
    }
  }, [selectedRoute]);

  useEffect(() => {
    if (selectedRoute && isSimulating) {
      const interval = setInterval(() => {
        setPlanePosition((prev) => {
          if (prev >= selectedRoute.path.length - 1) {
            clearInterval(interval);
            setIsSimulating(false);
            return selectedRoute.path.length - 1;
          }
          return prev + 0.02;
        });
      }, 50);
      return () => clearInterval(interval);
    }
  }, [selectedRoute, isSimulating]);

  const calculateRouteCost = (path: string[], priority: string) => {
    let totalCost = 0;
    for (let i = 0; i < path.length - 1; i++) {
      const edge = routes.find(e => 
        (e.from === path[i] && e.to === path[i + 1]) ||
        (e.to === path[i] && e.from === path[i + 1])
      );
      if (edge) {
        const weatherFactor = conditionFactors.weather[edge.weather];
        const altitudeFactor = conditionFactors.altitude[edge.altitude];
        switch (priority) {
          case 'distance':
            totalCost += edge.distance;
            break;
          case 'fuel':
            totalCost += edge.fuelCost;
            break;
          case 'weather':
            totalCost += (weatherFactor);
            break;
          default:
            totalCost += (edge.distance + edge.fuelCost) / 2;
        }
      }
    }
    return totalCost;
  };

  const findRoutes = (start: string, end: string, priority: string) => {
    const paths: Array<{ path: string[]; cost: number }> = [];
    const visited = new Set<string>();

    const dfs = (current: string, path: string[], cost: number) => {
      if (current === end) {
        paths.push({ path: [...path], cost });
        return;
      }

      visited.add(current);

      const edges = routes.filter(route => 
        (route.from === current && !visited.has(route.to)) ||
        (route.to === current && !visited.has(route.from))
      );

      for (const edge of edges) {
        const next = edge.from === current ? edge.to : edge.from;
        if (!visited.has(next) && edge.weather !== 'storm') {
          const newCost = cost + calculateRouteCost([current, next], priority);
          path.push(next);
          dfs(next, path, newCost);
          path.pop();
        }
      }

      visited.delete(current);
    };

    dfs(start, [start], 0);

    if (paths.length === 0) {
      setError("No storm-free route available between these airports.");
      return [];
    }

    setError(null);
    return paths.sort((a, b) => a.cost - b.cost).slice(0, 3);
  };

  const handleRouteSearch = () => {
    const results = findRoutes(source, destination, routingPriority);
    setAvailableRoutes(results);
    setSelectedRoute(results.length > 0 ? results[0] : null);
  };

  const handleWeatherChange = (from: string, to: string, weather: Route['weather']) => {
    const newRoutes = routes.map(route => {
      if ((route.from === from && route.to === to) || (route.from === to && route.to === from)) {
        return { ...route, weather };
      }
      return route;
    });
    setRoutes(newRoutes);

    if (isSimulating && selectedRoute) {
      const isAffectedRoute = selectedRoute.path.some((airport, index) => {
        if (index === selectedRoute.path.length - 1) return false;
        const nextAirport = selectedRoute.path[index + 1];
        return (airport === from && nextAirport === to) || 
               (airport === to && nextAirport === from);
      });

      if (isAffectedRoute && weather === 'storm') {
        const newRoutes = findRoutes(source, destination, routingPriority);
        if (newRoutes.length > 0) {
          setAvailableRoutes(newRoutes);
          setSelectedRoute(newRoutes[0]);
          setError(null);
        } else {
          setAvailableRoutes([]);
          setSelectedRoute(null);
          setError("No storm-free route available between these airports.");
        }
      }
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="bg-white shadow-xl rounded-xl overflow-hidden">
        <div className="p-6 bg-gradient-to-r from-blue-600 to-blue-800">
          <h1 className="text-3xl font-bold text-white text-center">Smart Airlift Router</h1>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div>
              <label className="block font-semibold mb-1 text-gray-600">Source</label>
              <select
                value={source}
                onChange={(e) => setSource(e.target.value)}
                className="border rounded px-3 py-2 w-full focus:outline-none focus:border-blue-400"
              >
                <option value="">Select Source</option>
                {airports.map((airport) => (
                  <option key={airport.id} value={airport.id}>{airport.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-gray-600">Destination</label>
              <select
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                className="border rounded px-3 py-2 w-full focus:outline-none focus:border-blue-400"
              >
                <option value="">Select Destination</option>
                {airports.map((airport) => (
                  <option key={airport.id} value={airport.id}>{airport.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold mb-1 text-gray-600">Priority</label>
              <select
                value={routingPriority}
                onChange={(e) => setRoutingPriority(e.target.value)}
                className="border rounded px-3 py-2 w-full focus:outline-none focus:border-blue-400"
              >
                <option value="balanced">Balanced</option>
                <option value="distance">Shortest Distance</option>
                <option value="fuel">Fuel Efficient</option>
                <option value="weather">Weather Optimal</option>
              </select>
            </div>

            <button
              onClick={handleRouteSearch}
              className="mt-6 bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded shadow-md transition-all duration-200"
            >
              Find Routes
            </button>
          </div>

          {error && (
            <div className="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
              {error}
            </div>
          )}

          <div className="border rounded p-4 mb-8 bg-gray-50">
            <NetworkMap
              airports={airports}
              routes={routes}
              selectedRoute={selectedRoute}
              planePosition={planePosition}
              onWeatherChange={handleWeatherChange}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h2 className="text-xl font-semibold mb-4 text-gray-700">Available Routes</h2>
              <div className="space-y-3">
                {availableRoutes.map((route, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedRoute(route)}
                    className={`w-full text-left rounded-md py-3 px-4 transition-all duration-200 font-medium shadow-sm
                      ${
                        selectedRoute === route
                          ? 'bg-blue-500 text-white'
                          : 'bg-gray-200 hover:bg-gray-300 text-gray-700'
                      }`}
                  >
                    Route {index + 1} (Cost: {Math.round(route.cost)} units)
                  </button>
                ))}
              </div>
            </div>

            <div>
              <h2 className="text-xl font-semibold mb-4 text-gray-700">Route Details</h2>
              {selectedRoute && (
                <div className="p-4 bg-gray-50 rounded-md shadow">
                  <p className="text-gray-600"><strong>Path:</strong> {selectedRoute.path.join(' → ')}</p>
                  <p className="text-gray-600"><strong>Total Cost:</strong> {Math.round(selectedRoute.cost)} units</p>
                  <div className="mt-4">
                    <h3 className="font-semibold text-gray-700 mb-2">Weather Conditions:</h3>
                    <div className="space-y-2">
                      {selectedRoute.path.slice(0, -1).map((airport, index) => {
                        const nextAirport = selectedRoute.path[index + 1];
                        const route = routes.find(r => 
                          (r.from === airport && r.to === nextAirport) ||
                          (r.to === airport && r.from === nextAirport)
                        );
                        if (!route) return null;
                        return (
                          <div key={index} className="flex items-center justify-between text-sm">
                            <span>{airport} → {nextAirport}:</span>
                            <span className={`px-2 py-1 rounded flex items-center gap-2 ${
                              route.weather === 'clear' ? 'bg-green-100 text-green-800' :
                              route.weather === 'rain' ? 'bg-blue-100 text-blue-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              <WeatherIcon weather={route.weather} className="w-4 h-4" />
                              {route.weather.charAt(0).toUpperCase() + route.weather.slice(1)}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="mt-8 p-4 bg-blue-50 rounded-md">
            <h3 className="text-lg font-semibold text-blue-800 mb-2">Weather Conditions Legend</h3>
            <div className="grid grid-cols-3 gap-4">
              <div className="flex items-center gap-2">
                <WeatherIcon weather="clear" className="w-4 h-4 text-gray-600" />
                <span className="text-sm text-gray-600">Clear</span>
              </div>
              <div className="flex items-center gap-2">
                <WeatherIcon weather="rain" className="w-4 h-4 text-blue-600" />
                <span className="text-sm text-gray-600">Rain</span>
              </div>
              <div className="flex items-center gap-2">
                <WeatherIcon weather="storm" className="w-4 h-4 text-red-600" />
                <span className="text-sm text-gray-600">Storm</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SmartAirliftRouter;