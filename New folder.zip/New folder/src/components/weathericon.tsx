import React from 'react';
import { Cloud, CloudRain, CloudLightning } from 'lucide-react';

interface WeatherIconProps {
  weather: 'clear' | 'rain' | 'storm';
  className?: string;
}

export const WeatherIcon: React.FC<WeatherIconProps> = ({ weather, className = '' }) => {
  switch (weather) {
    case 'clear':
      return <Cloud className={className} />;
    case 'rain':
      return <CloudRain className={className} />;
    case 'storm':
      return <CloudLightning className={className} />;
  }
};